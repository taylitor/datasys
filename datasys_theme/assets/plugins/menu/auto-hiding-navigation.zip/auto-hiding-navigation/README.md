Auto-Hiding Navigation
=========
A simple navigation that auto-hides when the user scrolls down, and becomes visible when the user scrolls up.

[Article on CodyHouse](https://codyhouse.co/gem/auto-hiding-navigation)

[Demo](https://codyhouse.co/demo/auto-hiding-navigation/nav-subnav.html)

Images: [Unsplash](https://unsplash.com/)
 
[Terms](https://codyhouse.co/terms/)
